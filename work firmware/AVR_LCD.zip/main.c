//*****************************************************************************
//
// File Name	: 'main.c'
// Title		: LCD demo
// Author		: Scienceprog.com - Copyright (C) 2007
// Created		: 2007-03-29
// Revised		: 2007-03-29
// Version		: 1.0
// Target MCU	: Atmel AVR series
//
// This code is distributed under the GNU Public License
//		which can be found at http://www.gnu.org/licenses/gpl.txt
//
//*****************************************************************************

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <util/delay.h>
#include "lcd_lib.h"

//Strings stored in AVR Flash memory
const uint8_t welcomeln1[] PROGMEM="AVR LCD DEMO\0";
const uint8_t curhome[] PROGMEM="LCD cursor Home\0";
const uint8_t customsymbol1[] PROGMEM="Define symbol\0";
const uint8_t customsymbol2[] PROGMEM="at CGRAM addr=0\0";
const uint8_t customsymbolout[] PROGMEM="Output symbol\0";
const uint8_t shift[] PROGMEM="<-Shift->\0";
const uint8_t shiftdemo[] PROGMEM="Shift DEMO\0";
const uint8_t lcdblank[] PROGMEM="LCD blank DEMO\0";
const uint8_t lcdanimation[] PROGMEM="LCD animation DEMO\0";

// custom LCD characters
const uint8_t backslash[] PROGMEM= 
{
0b00000000,//back slash
0b00010000,
0b00001000,
0b00000100,
0b00000010,
0b00000001,
0b00000000,
0b00000000
};
//delay 1s
void delay1s(void)
{
	uint8_t i;
	for(i=0;i<100;i++)
	{
		_delay_ms(10);
	}
}
//demonstration of shift
void demoshift(void)
{
	LCDclr();
	CopyStringtoLCD(shift, 3, 0);
	delay1s();
	CopyStringtoLCD(welcomeln1, 3, 1);	
	for(uint8_t i=0;i<5;i++)
		{
			delay1s();
			LCDshiftLeft(1);
			delay1s();
			LCDshiftRight(1);
		}
}
//demostration of blank
void demolcdblank(void)
{
	LCDclr();
	CopyStringtoLCD(lcdblank, 0, 0);
	for(uint8_t i=0;i<5;i++)
		{
			LCDblank();
			delay1s();
			LCDvisible();
			delay1s();
		}
}
//demonstration of animation
void demoanimation(void)
{
	LCDclr();
	CopyStringtoLCD(customsymbol1, 0, 0);
	CopyStringtoLCD(customsymbol2, 0, 1);
	delay1s();
	LCDdefinechar(backslash,0);
	LCDclr();
	CopyStringtoLCD(customsymbolout, 0, 0);
	LCDGotoXY(8, 1);
	LCDsendChar(0);
	delay1s();
	LCDclr();
	CopyStringtoLCD(lcdanimation, 0, 0);
	for(uint8_t i=0;i<3;i++)
		{
			LCDGotoXY(8, 1);
			LCDsendChar(0);
			delay1s();
			LCDGotoXY(8, 1);
			LCDsendChar('-');
			delay1s();
			LCDGotoXY(8, 1);
			LCDsendChar('/');
			delay1s();
			LCDGotoXY(8, 1);
			LCDsendChar('|');
			delay1s();
			LCDGotoXY(8, 1);
			LCDsendChar(0);
			delay1s();
			LCDGotoXY(8, 1);
			LCDsendChar('-');
			delay1s();
			LCDGotoXY(8, 1);
			LCDsendChar('/');
			delay1s();
			LCDGotoXY(8, 1);
			LCDsendChar('|');
			delay1s();
		}	
}

int main(void)
{
	LCDinit();//init LCD 8 bit, dual line, cursor right
	LCDclr();//clears LCD
	CopyStringtoLCD(curhome, 0, 0);//Cursor home and display message
	delay1s();
	LCDclr();//clears LCD
	LCDhome();//cursonr home
	while(1)//loop demos
	{
		demoshift();
		demolcdblank();
		demoanimation();
	}
	return 0;
}
